<?php
namespace GixOC;
class GixOC {
	public function __construct() {
	}
}